Add production GLB/GLTF cars, environment models, textures and audio here.
