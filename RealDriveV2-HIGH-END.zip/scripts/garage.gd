extends Node
var cars=[{"name":"Street X","price":0,"speed":240,"handling":72},{"name":"Night GT","price":2500,"speed":285,"handling":80},{"name":"Hyper R","price":8000,"speed":335,"handling":88}]
var selected_car:=0
func select_car(i:int):
    if i>=0 and i<cars.size():selected_car=i
func get_selected_car()->Dictionary:return cars[selected_car]
