extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var hud: CanvasLayer
var speed:=0.0
var distance:=0.0
var health:=100.0
var nitro:=100.0
var timer:=0.0
var traffic:Array[Node3D]=[]
var segments:Array[Node3D]=[]
var dead:=false
const W:=18.0
const L:=30.0
const N:=30
const MAX:=72.0

func _ready():
    world()
    car()
    cam()
    ui()

func world():
    var env:=WorldEnvironment.new()
    var e:=Environment.new()
    e.background_mode=Environment.BG_COLOR
    e.background_color=Color(0.02,0.035,0.07)
    e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color=Color(0.7,0.75,0.9)
    e.ambient_light_energy=0.8
    env.environment=e
    add_child(env)
    var sun:=DirectionalLight3D.new()
    sun.rotation_degrees=Vector3(-55,-25,0)
    sun.light_energy=1.2
    sun.shadow_enabled=true
    add_child(sun)
    for i in N: segment(i)

func segment(i):
    var s:=Node3D.new()
    s.position.z=-i*L
    add_child(s)
    segments.append(s)
    var m:=MeshInstance3D.new()
    var b:=BoxMesh.new()
    b.size=Vector3(W,.16,L)
    m.mesh=b
    var mat:=StandardMaterial3D.new()
    mat.albedo_color=Color(.045,.05,.055)
    m.material_override=mat
    s.add_child(m)
    for x in [-W/2.0,W/2.0]:
        var rail:=MeshInstance3D.new()
        var rb:=BoxMesh.new()
        rb.size=Vector3(.22,.7,L)
        rail.mesh=rb
        rail.position=Vector3(x,.35,0)
        s.add_child(rail)
    for lane in range(1,3):
        var line:=MeshInstance3D.new()
        var lb:=BoxMesh.new()
        lb.size=Vector3(.1,.025,L*.45)
        line.mesh=lb
        line.position=Vector3(-W/2.0+lane*W/3.0,.1,0)
        var lm:=StandardMaterial3D.new()
        lm.albedo_color=Color(.95,.9,.55)
        line.material_override=lm
        s.add_child(line)

func car():
    player=CharacterBody3D.new()
    player.position=Vector3(0,.65,2)
    add_child(player)
    var body:=MeshInstance3D.new()
    var b:=BoxMesh.new()
    b.size=Vector3(2.2,.7,4.4)
    body.mesh=b
    var mat:=StandardMaterial3D.new()
    mat.albedo_color=Color(.04,.3,.95)
    mat.metallic=.7
    mat.roughness=.22
    body.material_override=mat
    player.add_child(body)
    var col:=CollisionShape3D.new()
    var sh:=BoxShape3D.new()
    sh.size=Vector3(2.2,1,4.4)
    col.shape=sh
    player.add_child(col)

func cam():
    camera=Camera3D.new()
    camera.position=Vector3(0,5.5,10)
    camera.current=true
    add_child(camera)

func ui():
    hud=CanvasLayer.new()
    add_child(hud)
    var t:=Label.new()
    t.text="REALDRIVE V2 • HIGH-END"
    t.position=Vector2(28,22)
    t.add_theme_font_size_override("font_size",28)
    hud.add_child(t)
    var s:=Label.new()
    s.name="Stats"
    s.position=Vector2(28,62)
    s.add_theme_font_size_override("font_size",20)
    hud.add_child(s)
    var v:=Label.new()
    v.name="Speed"
    v.position=Vector2(1030,575)
    v.add_theme_font_size_override("font_size",34)
    hud.add_child(v)
    var h:=Label.new()
    h.text="A/D STEER   W ACCELERATE   S BRAKE   SPACE NITRO"
    h.position=Vector2(28,675)
    h.add_theme_font_size_override("font_size",17)
    hud.add_child(h)

func _physics_process(d):
    if dead:return
    var a=Input.get_axis("brake","accelerate")
    if a>0:speed=min(MAX,speed+24*d)
    elif a<0:speed=max(0,speed-42*d)
    else:speed=max(0,speed-7*d)
    if Input.is_action_pressed("nitro") and nitro>0:
        speed=min(MAX*1.45,speed+38*d)
        nitro=max(0,nitro-25*d)
    else:nitro=min(100,nitro+8*d)
    player.velocity.x=Input.get_axis("steer_left","steer_right")*28
    player.move_and_slide()
    player.position.x=clamp(player.position.x,-7.2,7.2)
    distance+=speed*d
    for s in segments:
        s.position.z+=speed*d
        if s.position.z>L:s.position.z-=N*L
    timer-=d
    if timer<=0:
        spawn()
        timer=max(.5,1.5-speed/90)
    for c in traffic.duplicate():
        c.position.z+=speed*d*.78
        if c.position.z>20:
            traffic.erase(c);c.queue_free()
        elif abs(c.position.x-player.position.x)<1.8 and abs(c.position.z-player.position.z)<2.8:
            health-=38*d
            speed*=.97
            if health<=0:dead=true
    camera.position=camera.position.lerp(player.position+Vector3(0,5.2,10),min(1.0,d*5))
    camera.look_at(player.position+Vector3(0,.7,-10))
    hud.get_node("Stats").text="SCORE %06d   COINS %03d   HP %03d   NITRO %03d%%"%[int(distance*3),int(distance/100),int(health),int(nitro)]
    hud.get_node("Speed").text="%03d KM/H"%int(speed*4)
    if dead:hud.get_node("Stats").text="CRASHED — PRESS R TO RESTART"

func spawn():
    var c:=Node3D.new()
    c.position=Vector3([-6.0,0,6.0].pick_random(),.6,-115)
    add_child(c)
    var m:=MeshInstance3D.new()
    var b:=BoxMesh.new()
    b.size=Vector3(2,.75,4)
    m.mesh=b
    var mat:=StandardMaterial3D.new()
    mat.albedo_color=[Color(.85,.08,.08),Color(.95,.72,.04),Color(.08,.65,.35),Color(.65,.68,.72)].pick_random()
    m.material_override=mat
    c.add_child(m)
    traffic.append(c)

func _input(e):
    if dead and e is InputEventKey and e.pressed and e.keycode==KEY_R:get_tree().reload_current_scene()
