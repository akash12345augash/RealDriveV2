package com.realdrive.v2;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new DriveView(this));
    }

    static class DriveView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Random random = new Random();
        final ArrayList<Traffic> traffic = new ArrayList<>();
        float carX = .5f, speed = .006f, roadScroll = 0;
        boolean left, right, nitro;
        int score = 0;
        long last = System.nanoTime();

        DriveView(Context c) {
            super(c);
            for (int i = 0; i < 5; i++)
                traffic.add(new Traffic(.2f + random.nextFloat()*.6f, .12f + i*.18f));
        }

        static class Traffic {
            float lane, depth;
            Traffic(float l, float d) { lane=l; depth=d; }
        }

        @Override protected void onDraw(Canvas c) {
            long now = System.nanoTime();
            float dt = Math.min(.04f, (now-last)/1_000_000_000f);
            last = now;
            update(dt);
            drawScene(c);
            postInvalidateOnAnimation();
        }

        void update(float dt) {
            float steer = (right ? 1 : 0) - (left ? 1 : 0);
            carX = Math.max(.15f, Math.min(.85f, carX + steer*.55f*dt));
            float actual = speed * (nitro ? 2.2f : 1f);
            roadScroll += actual*dt*3f;
            for (Traffic t : traffic) {
                t.depth += actual*dt;
                if (t.depth > 1.08f) {
                    t.depth=-.05f;
                    t.lane=.2f+random.nextFloat()*.6f;
                    score++;
                }
            }
        }

        void drawScene(Canvas c) {
            int w=getWidth(), h=getHeight();
            float horizon=h*.36f, cx=w*.5f;
            c.drawColor(Color.rgb(105,165,210));

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(70,92,105));
            for(int i=0;i<16;i++){
                float bw=w/18f, bh=18+(i*37)%70;
                c.drawRect(i*bw,horizon-bh,i*bw+bw-2,horizon,p);
            }

            p.setColor(Color.rgb(42,115,55));
            c.drawRect(0,horizon,w,h,p);

            Path road=new Path();
            road.moveTo(cx-42,horizon); road.lineTo(cx+42,horizon);
            road.lineTo(w*.92f,h); road.lineTo(w*.08f,h); road.close();
            p.setColor(Color.rgb(48,50,53)); c.drawPath(road,p);

            p.setColor(Color.WHITE); p.setStrokeWidth(5);
            c.drawLine(cx-42,horizon,w*.08f,h,p);
            c.drawLine(cx+42,horizon,w*.92f,h,p);

            p.setColor(Color.rgb(245,220,70)); p.setStrokeWidth(6);
            for(int i=0;i<9;i++){
                float z0=((i/9f)+roadScroll)%1f;
                float z1=Math.min(1f,z0+.055f);
                float y0=horizon+(float)Math.pow(z0,1.7)*(h-horizon);
                float y1=horizon+(float)Math.pow(z1,1.7)*(h-horizon);
                c.drawLine(cx,y0,cx,y1,p);
            }

            for(Traffic t:traffic) drawTraffic(c,t,cx,horizon,w,h);
            drawPlayer(c,cx,w,h);

            p.setColor(0xAA000000);
            c.drawRoundRect(18,18,205,75,16,16,p);
            p.setColor(Color.WHITE); p.setTextSize(25);
            c.drawText("SCORE  "+score,32,55,p);

            drawButton(c,30,h-115,150,h-25,"◀");
            drawButton(c,w-150,h-115,w-30,h-25,"▶");
            drawButton(c,w*.5f-70,h-105,w*.5f+70,h-35,"NITRO");
        }

        void drawTraffic(Canvas c, Traffic t, float cx, float horizon, int w, int h) {
            float z=Math.max(0,Math.min(1,t.depth));
            float y=horizon+(float)Math.pow(z,1.65)*(h-horizon);
            float roadHalf=42+z*(w*.42f-42);
            float x=cx+(t.lane-.5f)*roadHalf*1.65f;
            float s=10+z*48;
            p.setColor(Color.rgb(190,45,45));
            c.drawRoundRect(x-s,y-s*.55f,x+s,y+s*.55f,s*.18f,s*.18f,p);
            p.setColor(Color.rgb(35,45,55));
            c.drawRect(x-s*.55f,y-s*.42f,x+s*.55f,y-s*.05f,p);
        }

        void drawPlayer(Canvas c, float cx, int w, int h) {
            float x=cx+(carX-.5f)*w*.72f, y=h-125, s=Math.min(w,h)*.16f;
            p.setColor(nitro?Color.rgb(255,170,30):Color.rgb(35,105,235));
            c.drawRoundRect(x-s,y-s*.5f,x+s,y+s*.5f,s*.2f,s*.2f,p);
            p.setColor(Color.rgb(20,30,40));
            c.drawRect(x-s*.52f,y-s*.37f,x+s*.52f,y-s*.02f,p);
            p.setColor(Color.BLACK);
            c.drawCircle(x-s*.65f,y+s*.38f,s*.2f,p);
            c.drawCircle(x+s*.65f,y+s*.38f,s*.2f,p);
        }

        void drawButton(Canvas c,float l,float t,float r,float b,String text) {
            p.setColor(0x99000000); c.drawRoundRect(l,t,r,b,22,22,p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(text.equals("NITRO")?22:38);
            c.drawText(text,(l+r)/2f,(t+b)/2f+p.getTextSize()*.34f,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY(); int w=getWidth(), h=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                left=x<180 && y>h-140;
                right=x>w-180 && y>h-140;
                nitro=x>w*.5f-90 && x<w*.5f+90 && y>h-125;
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){
                left=right=nitro=false; return true;
            }
            return true;
        }
    }
}
