# RealDrive V2
Corrected Android driving game project.

The Canvas `drawLine()` call is fixed and the project is structured for
Android SDK 35 / Gradle 8.7.

Features: perspective road, traffic, steering, nitro and score.
