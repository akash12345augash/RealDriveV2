# Real Drive V2

A self-contained Android driving-game prototype inspired by the provided UI mockup.

## V2 features
- Perspective 3D-style moving highway
- Procedural city/building backdrop
- Traffic vehicles with lane movement
- Accelerate / brake / steering touch controls
- Drift mode
- Nitro boost with recharge
- Collision and crash overlay
- Vehicle health and coins
- Main menu
- Garage
- Three selectable cars with different performance
- Landscape Android UI
- GitHub Actions workflow that builds a debug APK

## Build on GitHub
1. Create a new GitHub repository.
2. Upload all files in this folder.
3. Open **Actions → Build Real Drive V2 APK → Run workflow**.
4. Download the `RealDriveV2-debug-apk` artifact.

This is a playable 2D-rendered/perspective-3D prototype, not a full Unity/Unreal AAA 3D engine game. The road, vehicles, HUD and effects are rendered at runtime with Android Canvas, so no paid assets are required.
