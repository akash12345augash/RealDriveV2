package com.realdrive.v2;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); setContentView(new DriveView(this));}
}

class DriveView extends View {
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Random rnd=new Random(8); long last;
  int screen=0; // 0 menu, 1 drive, 2 garage, 3 cars
  float speed=0, playerX=0, roadScroll=0, nitro=100, health=100, coins=12450;
  boolean gas, brake, left, right, drift, nitroDown; boolean crashed=false; float crashT=0;
  int car=0; float steerVisual=0;
  ArrayList<Traffic> traffic=new ArrayList<>();
  String[] carNames={"NIGHTFURY GT","TORQUE RS","VORTEX X"};
  int[] carCost={0,6500,12500};
  public DriveView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); last=System.nanoTime(); for(int i=0;i<7;i++) traffic.add(new Traffic(i)); setFocusable(true);}
  void txt(Canvas c,String s,float x,float y,float size,int color){p.setTextSize(size);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
  void box(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
  @Override protected void onDraw(Canvas c){super.onDraw(c); float dt=Math.min(.04f,(System.nanoTime()-last)/1e9f); last=System.nanoTime(); if(screen==0)menu(c); else if(screen==1)drive(c,dt); else if(screen==2)garage(c); else cars(c); postInvalidateDelayed(16);}

  void menu(Canvas c){
    drawSky(c); txt(c,"REAL DRIVE",55,105,58,Color.WHITE); txt(c,"V2",355,105,58,0xff00e5ff); txt(c,"MOBILE",58,142,22,0xffa8b8c8);
    // hero car
    drawCar(c,getWidth()/2f,360,1.8f,0xff1268d4,0,0);
    box(c,55,470,520,555,22,0xff101722); txt(c,"▶  START DRIVE",95,525,28,Color.WHITE);
    box(c,55,575,520,650,20,0xff172331); txt(c,"▣  GARAGE",95,620,24,0xffd9e5ee);
    box(c,55,670,520,745,20,0xff172331); txt(c,"⚙  SETTINGS",95,715,24,0xffd9e5ee);
    txt(c,"VERSION 2.0 • 3D ROAD • TRAFFIC • DRIFT • NITRO",600,715,16,0xff8da0b1);
    txt(c,"COINS  "+(int)coins,600,80,22,0xffffd54a);
    // buttons
    hitLabel(c,"GARAGE",600,220,930,300); hitLabel(c,"CAR SELECT",600,330,930,410); hitLabel(c,"PLAY",600,440,930,540);
  }
  void hitLabel(Canvas c,String s,float l,float t,float r,float b){box(c,l,t,r,b,18,0xff0d1b28); txt(c,s,l+28,t+52,26,Color.WHITE);}
  void drawSky(Canvas c){c.drawColor(0xff08111d); p.setShader(new LinearGradient(0,0,0,getHeight(),0xff152c49,0xff06090d,Shader.TileMode.CLAMP)); c.drawRect(0,0,getWidth(),getHeight(),p);p.setShader(null); for(int i=0;i<30;i++){p.setColor(0x557da1bd); c.drawRect(i*45,250-(i%3)*20,i*45+22,450,p);} }

  void drive(Canvas c,float dt){
    update(dt); drawRoad(c); drawTraffic(c); drawPlayer(c); hud(c); if(crashed) crashOverlay(c);
  }
  void update(float dt){
    if(crashed){crashT+=dt; if(crashT>2.3f){crashed=false; health=100; speed=0; playerX=0; crashT=0;} return;}
    float target=gas?1:0; if(brake)target=-.6f; speed += (target*115-speed)*dt*1.8f; speed=Math.max(0,Math.min(185,speed));
    float sx=(right?1:0)-(left?1:0); if(drift && Math.abs(sx)<.1f) sx=steerVisual*.5f; playerX += sx*dt*(drift?1.5f:1.0f)*(speed/70f); playerX=Math.max(-1.15f,Math.min(1.15f,playerX));
    steerVisual += (sx-steerVisual)*dt*8; roadScroll += speed*dt*(drift?1.8f:1f); if(nitroDown && nitro>0){speed=Math.min(215,speed+55*dt); nitro-=25*dt;} else nitro=Math.min(100,nitro+6*dt);
    for(Traffic t:traffic){t.z-=dt*(0.10f+speed/900f); if(t.z<0.04f){t.reset(); coins+=10;}}
    for(Traffic t:traffic){if(t.z<.19f && t.z>.08f && Math.abs(t.lane-playerX)<.22f && speed>35){crashed=true; health-=35;}}
  }
  void drawRoad(Canvas c){
    int w=getWidth(),h=getHeight(); c.drawColor(0xff0a1118); p.setShader(new LinearGradient(0,0,0,h,0xff1d4564,0xff090b0f,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
    float horizon=h*.35f, cx=w*.56f; Path road=new Path();road.moveTo(cx-65,horizon);road.lineTo(cx+65,horizon);road.lineTo(w*.94f,h);road.lineTo(w*.08f,h);road.close();p.setColor(0xff25292d);c.drawPath(road,p);
    // shoulders
    p.setColor(0xff4d5358);p.setStrokeWidth(8);c.drawLine(cx-65,horizon,cx-w*.48f,h,p);c.drawLine(cx+65,horizon,cx+w*.38f,h,8,p);
    // lane dashes with perspective motion
    for(int i=0;i<16;i++){float z=((i/16f)+(roadScroll*.008f))%1f;float y=horizon+(float)Math.pow(z,1.7)* (h-horizon);float half=65+(w*.43f)*z; float dash=10+55*z; p.setColor(0xffdfe4e8);p.setStrokeWidth(Math.max(2,6*z)); c.drawLine(cx-half/3,y,cx-half/3,y+dash,p);c.drawLine(cx+half/3,y,cx+half/3,y+dash,p);}
    // buildings/lights
    for(int i=0;i<18;i++){float x=(i*91)%w;float bh=80+(i%5)*35; p.setColor(0xff16202a);c.drawRect(x,horizon-bh,x+50,horizon,p);p.setColor(0xffd9a64d);for(int q=0;q<4;q++)c.drawRect(x+8+q*10,horizon-bh+12,x+13+q*10,horizon-bh+19,p);}
  }
  void drawTraffic(Canvas c){for(Traffic t:traffic){float z=t.z;float y=getHeight()*.35f+(float)Math.pow(1-z,1.65)*(getHeight()*.65f);float s=.18f+(1-z)*1.05f;float cx=getWidth()*.56f+t.lane*getWidth()*.18f*(1-z);drawCar(c,cx,y,s,t.color,0,0);}}
  void drawPlayer(Canvas c){float x=getWidth()*.56f+playerX*getWidth()*.18f;float y=getHeight()*.80f;drawCar(c,x,y,1.28f,car==0?0xff176bd8:car==1?0xffd83a2e:0xff7b3fe4,steerVisual,drift?1:0);}
  void drawCar(Canvas c,float x,float y,float s,int color,float steer,int fx){p.setColor(0x44000000);c.drawOval(x-95*s,y+42*s,x+95*s,y+75*s,p);p.setColor(color);Path b=new Path();b.moveTo(x-78*s,y+45*s);b.lineTo(x-62*s,y-18*s);b.lineTo(x-40*s,y-54*s);b.lineTo(x+40*s,y-54*s);b.lineTo(x+62*s,y-18*s);b.lineTo(x+78*s,y+45*s);b.close();c.drawPath(b,p);p.setColor(0xff0b1118);Path win=new Path();win.moveTo(x-35*s,y-47*s);win.lineTo(x+35*s,y-47*s);win.lineTo(x+50*s,y-16*s);win.lineTo(x-50*s,y-16*s);win.close();c.drawPath(win,p);p.setColor(0xffff3448);c.drawRoundRect(x-66*s,y+5*s,x-47*s,y+25*s,6*s,6*s,p);c.drawRoundRect(x+47*s,y+5*s,x+66*s,y+25*s,6*s,6*s,p); if(fx==1){p.setColor(0xff00e5ff);c.drawCircle(x-80*s,y+35*s,12*s,p);c.drawCircle(x+80*s,y+35*s,12*s,p);}}
  void hud(Canvas c){int w=getWidth(),h=getHeight();box(c,18,18,380,86,16,0xcc0b121b);txt(c,"LEVEL 4",38,46,16,0xff8fa8bb);txt(c,"CITY RUN",38,70,23,Color.WHITE);box(c,400,18,880,86,16,0xcc0b121b);txt(c,"MISSION",425,45,13,0xff00e5ff);txt(c,"Reach the next checkpoint   2.1 km",425,68,18,Color.WHITE);box(c,w-260,18,w-20,86,16,0xcc0b121b);txt(c,"● "+(int)coins, w-235,57,20,0xffffd54a);
    box(c,20,h-160,220,h-20,22,0x99101822);txt(c,"◀",55,h-72,42,Color.WHITE);txt(c,"▶",145,h-72,42,Color.WHITE);
    box(c,w-240,h-170,w-20,h-20,22,0x99101822);txt(c,"BRAKE",w-220,h-115,17,0xffe8eef3);txt(c,"GAS",w-110,h-115,17,0xffe8eef3);
    // speedometer
    txt(c,String.valueOf((int)speed),w/2f-48,h-70,48,Color.WHITE);txt(c,"KM/H",w/2f-26,h-43,13,0xff9db1c2);txt(c,drift?"DRIFT":"D",w/2f+38,h-43,15,drift?0xffffa52b:0xff00ef9b);
    box(c,w-330,h-260,w-205,h-135,18,0xaa0d1824);txt(c,"⚡",w-292,h-202,32,0xff00e5ff);txt(c,"NOS "+(int)nitro+"%",w-315,h-160,13,Color.WHITE);
    box(c,25,110,260,137,14,0xaa0d1824);txt(c,"HEALTH "+(int)health+"%",40,129,13,Color.WHITE);p.setColor(0xff18e37c);c.drawRect(120,119,120+110*health/100,129,p);
  }
  void crashOverlay(Canvas c){p.setColor(0x99000000);c.drawRect(0,0,getWidth(),getHeight(),p);txt(c,"CRASH!",getWidth()/2f-110,getHeight()/2f,55,0xffff455a);txt(c,"Vehicle repaired automatically",getWidth()/2f-145,getHeight()/2f+38,18,Color.WHITE);}

  void garage(Canvas c){drawSky(c);txt(c,"GARAGE",50,75,38,Color.WHITE);txt(c,"Choose your ride",52,108,17,0xff9eb1c2);drawCar(c,getWidth()/2f,365,2.3f,car==0?0xff176bd8:car==1?0xffd83a2e:0xff7b3fe4,0,0);box(c,50,570,980,735,22,0xdd0b131d);txt(c,carNames[car],80,620,32,Color.WHITE);txt(c,"TOP SPEED   "+(car==0?190:car==1?205:220)+" KM/H",80,660,16,0xffb6c6d3);txt(c,"NITRO POWER  "+(car==0?100:car==1?120:140)+"%",80,690,16,0xffb6c6d3);box(c,820,610,945,690,18,0xff00a6c7);txt(c,"DRIVE",847,660,20,Color.WHITE);box(c,50,755,230,815,16,0xff182635);txt(c,"‹ BACK",88,793,19,Color.WHITE);box(c,250,755,460,815,16,0xff182635);txt(c,"CAR SELECT",280,793,19,Color.WHITE);}
  void cars(Canvas c){drawSky(c);txt(c,"CAR SELECT",45,70,36,Color.WHITE);for(int i=0;i<3;i++){float x=190+i*330;box(c,x-130,130,x+130,590,24,i==car?0xff132a3c:0xcc0b141e);drawCar(c,x,330,1.55f,i==0?0xff176bd8:i==1?0xffd83a2e:0xff7b3fe4,0,0);txt(c,carNames[i],x-105,500,20,Color.WHITE);txt(c,i==0?"OWNED":"COST "+carCost[i],x-75,535,16,i==car?0xff00e5ff:0xffffd54a);}box(c,45,650,270,720,16,0xff182635);txt(c,"‹ MENU",90,695,20,Color.WHITE);box(c,770,650,1000,720,16,0xff00a6c7);txt(c,"SELECT",830,695,20,Color.WHITE);}

  class Traffic {float z,lane;int color;Traffic(int i){reset();z=.12f+i*.11f;}void reset(){z=1.05f+rnd.nextFloat()*.4f;lane=(rnd.nextInt(5)-2)*.42f;color=new int[]{0xffd8dce0,0xffe04b3e,0xffd6a82f,0xff7d8da0,0xfff2f2f2}[rnd.nextInt(5)];}}
  @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();int w=getWidth(),h=getHeight();if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){if(screen==0){if(y>450&&y<570){screen=1;}else if(y>570&&y<650||x>580&&y>190&&y<310){screen=2;}else if(x>580&&y>320&&y<430){screen=3;}}else if(screen==1){gas=x>w*.72f&&y>h*.65f;brake=x>w*.55f&&x<w*.78f&&y>h*.65f;left=x<w*.28f&&y>h*.55f;right=x>w*.28f&&x<w*.48f&&y>h*.55f;nitroDown=x>w*.67f&&x<w*.84f&&y>h*.48f&&y<h*.72f;drift=Math.abs((right?1:0)-(left?1:0))>0&&speed>55;}else if(screen==2){if(y>750&&x<250)screen=0; else if(y>750&&x>250&&x<500)screen=3; else if(x>800&&y>600&&y<700)screen=1;}else {if(y>640&&x<300)screen=0; else if(y>120&&y<600){int pick=(int)((x)/330); if(pick>=0&&pick<3)car=pick;} else if(y>640&&x>760)screen=2;}} if(e.getAction()==MotionEvent.ACTION_UP){gas=brake=left=right=nitroDown=drift=false;} return true;}
}
